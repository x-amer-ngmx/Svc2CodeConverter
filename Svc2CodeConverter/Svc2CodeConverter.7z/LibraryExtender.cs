﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Svc2CodeConverter
{
    public class LibraryExtender
    {
        public static CodeGeneratorOptions GetOptions => new CodeGeneratorOptions {
            BracingStyle = "C",
            BlankLinesBetweenMembers = true,
            VerbatimOrder = true
        };

        /// <summary>
        /// Добавляет типы в сборку по условию where
        /// </summary>
        /// <param name="units">Список сборок</param>
        /// <param name="types">Список типов, из которых производится выбор</param>
        /// <param name="where">Условие для выбора типов из списка, которые в последующем будут добавлены в сборку</param>
        public static void AddEntities(Dictionary<string, CodeCompileUnit> units,
            Dictionary<string, CodeTypeDeclaration> types, Expression<Func<KeyValuePair<string, CodeTypeDeclaration>, bool>> where)
        {
            var entities = types
                .Where(where.Compile())
                .Select(t => t);

            foreach (var entity2Add in entities)
            {
                var moduleName = entity2Add.Key.Split('.').First();
                var imports = new List<string>();
                
                //Атрибуты сущности
                imports.AddRange(ProcessAttributes(entity2Add.Value.CustomAttributes));
                //Базовые типы сущности
                imports.AddRange(ProcessBaseTypes(entity2Add.Value.BaseTypes));

                //Методы, переменные сущности
                foreach (var method in entity2Add.Value.Members.OfType<CodeMemberMethod>())
                {
                    imports.AddRange(ProcessAttributes(method.CustomAttributes));
                    
                    foreach (var custAttribute in method.CustomAttributes.Cast<CodeAttributeDeclaration>().Where(t => t.Name == "ServiceKnownTypeAttribute" || t.Name == "FaultContractAttribute"))
                    {
                        var ca = custAttribute.Arguments.Cast<CodeAttributeArgument>().Select(t => t.Value).OfType<CodeTypeOfExpression>().First().Type.BaseType;
                        if (custAttribute.Name.Equals("FaultContractAttribute"))
                        {
                            ca = ca.Replace("dom.gosuslugi.ru.schema.integration.base.", "");
                            custAttribute.Arguments.Cast<CodeAttributeArgument>()
                                .Select(t => t.Value)
                                .OfType<CodeTypeOfExpression>()
                                .First()
                                .Type.BaseType = ca;
                        }

                        //var gettingType = GetTypeFromTypes(types, moduleName + '.' + ca);
                        var gettingTypes = GetSameTypesFromTypesIgnoreModuleName(types, ca);
                        imports.Add(AddTypeToUnit(units, gettingTypes.First(), gettingTypes.Length > 1 ? "GisTypes" : moduleName + "Types"));
                    }

                    /*Это метод и у него должен быть аргументы и возврат*/
                    if (!method.ReturnType.BaseType.Contains("System."))
                    {
                        var returnTypes = GetSameTypesFromTypesIgnoreModuleName(types, method.ReturnType.BaseType);
                        if (returnTypes.Any())
                        {
                            imports.Add(AddTypeToUnit(units, returnTypes.First(), moduleName));

                            /*Конструкторы сущности*/ /*Возвращающий тип имеет конструкторы*/
                            foreach (var ctor in returnTypes.First().Members.OfType<CodeConstructor>())
                            {
                                foreach (var ctorPars in ctor.Parameters.Cast<CodeParameterDeclarationExpression>())
                                {
                                    /*Здесь выбираются все типы, которые совпадают по имени, имя сборки игнорируется*/
                                    var paramTypes = GetSameTypesFromTypesIgnoreModuleName(types, ctorPars.Type.BaseType);
                                    imports.Add(AddTypeToUnit(units, paramTypes.First(),
                                        paramTypes.Length > 1 ? "GisTypes" : moduleName + "Types"));
                                }
                            }
                        }
                    }

                    imports.AddRange(
                        method.Parameters.Cast<CodeParameterDeclarationExpression>().Where(t => !t.Type.BaseType.Contains("System."))
                        .Select(methodParameter => GetTypeFromTypes(types, moduleName + '.' + methodParameter.Type.BaseType))
                        .Select(methodParameterType => AddTypeToUnit(units, methodParameterType, moduleName)));
                }

                var nsname = AddTypeToUnit(units, entity2Add.Value, moduleName);
                units[nsname].Namespaces[0].Imports.AddRange(
                    imports.Select(t => new CodeNamespaceImport(t))
                    .Where(import => units[nsname].Namespaces[0].Imports.Cast<CodeNamespaceImport>()
                    .All(t => t.Namespace != import.Namespace))
                    .ToArray());
            }
        }

        private static CodeTypeDeclaration[] GetSameTypesFromTypesIgnoreModuleName(
            Dictionary<string, CodeTypeDeclaration> types, string typeName)
        {
            return types.Where(t => t.Key.Split('.').Last().Equals(typeName)).Select(t => t.Value).ToArray();
        }

        private static CodeTypeDeclaration GetTypeFromTypes(Dictionary<string, CodeTypeDeclaration> types,
            string typeName)
        {
            var messageString = types.Any(t => t.Key.Equals(typeName)) ? string.Empty : "Message";
            return types.Where(t => t.Key == typeName + messageString).Select(t => t.Value).First();
        }

        private static string AddTypeToUnit(Dictionary<string, CodeCompileUnit> units, CodeTypeDeclaration type2Add, string moduleName)
        {
            if(moduleName.Contains("Async"))
                moduleName = moduleName.Replace("Async", "");

            if (!units.ContainsKey(moduleName))
            {
                var newUnit = new CodeCompileUnit
                {
                    UserData = { { "ModuleName", moduleName } },
                    Namespaces = { new CodeNamespace(), new CodeNamespace(moduleName) }
                };

                units.Add(moduleName, newUnit);
            }

            if (units[moduleName].Namespaces[1].Types.Cast<CodeTypeDeclaration>().Any(t => t.Name == type2Add.Name))
                return moduleName;

            var localImports = new List<string>();
            localImports.AddRange(ProcessAttributes(type2Add.CustomAttributes));
            localImports.AddRange(ProcessBaseTypes(type2Add.BaseTypes));

            foreach (var typeMember in type2Add.Members.OfType<CodeMemberProperty>())
            {
                localImports.AddRange(ProcessAttributes(typeMember.CustomAttributes));
            }
            
            units[moduleName].Namespaces[1].Types.Add(type2Add);
            units[moduleName].Namespaces[0].Imports.AddRange(
                localImports.Select(t => new CodeNamespaceImport(t))
                .Where(import => units[moduleName].Namespaces[0].Imports.Cast<CodeNamespaceImport>()
                .All(t => t.Namespace != import.Namespace)).ToArray());

            return moduleName;
        }

        /// <summary>
        /// Обработка типа (класса в сборке)
        /// </summary>
        /// <param name="type"></param>
        public static void ProcessType(CodeTypeDeclaration type)
        {
            /*Это не сам тип сообщения а упакованное сообщение с заголовком и телом*/
            /*if (type.Members.OfType<CodeMemberField>().Any(t => t.Type.BaseType == type.Name))
                type.Name = type.Name + "Message";*/

            type.IsPartial = false;
            RenameFieldInConstructor(type);
            ProcessTypeMembers(type);

            if (type.CustomAttributes.Cast<CodeAttributeDeclaration>().Any(an => an.Name.Contains("MessageContractAttribute")))
            {
                type.Name = type.Name + "Message";
            }

            /*Поправляем тип FAULT*/
            if (!type.IsInterface) return;/*Этот тип только в интерфейсе*/
            foreach (var method in type.Members.OfType<CodeMemberMethod>())
            {
                foreach (var custAttribute in method.CustomAttributes.Cast<CodeAttributeDeclaration>().Where(t => t.Name.Contains("FaultContractAttribute")))
                {
                    var ca = custAttribute.Arguments.Cast<CodeAttributeArgument>().Select(t => t.Value).OfType<CodeTypeOfExpression>().First().Type.BaseType;
                    ca = ca.Replace("dom.gosuslugi.ru.schema.integration.base.", "");
                    custAttribute.Arguments.Cast<CodeAttributeArgument>()
                        .Select(t => t.Value)
                        .OfType<CodeTypeOfExpression>()
                        .First()
                        .Type.BaseType = ca;
                }
            }
        }

        /// <summary>
        /// Обработка атрибутов типа (класса)
        /// Вывод из атрибутов адреса типа в сборке
        /// </summary>
        /// <param name="customAttributes"></param>
        public static List<string> ProcessAttributes(CodeAttributeDeclarationCollection customAttributes)
        {
            var nsImports = new List<string>();

            foreach (var customAttribute in customAttributes.Cast<CodeAttributeDeclaration>())
            {
                var complexName = SplitType(customAttribute.Name);
                if (string.IsNullOrEmpty(complexName.First())) continue;

                customAttribute.Name = customAttribute.Name.Replace(complexName.First(), "").TrimStart('.');

                if (nsImports.Contains(complexName.First())) continue;
                nsImports.Add(complexName.First());
            }

            return nsImports;
        }

        public static List<string> ProcessBaseTypes(CodeTypeReferenceCollection baseTypes)
        {
            var nsImports = new List<string>();

            foreach (var baseType in baseTypes.Cast<CodeTypeReference>())
            {
                var complexName = SplitType(baseType.BaseType);
                if (string.IsNullOrEmpty(complexName.First())) continue;
                baseType.BaseType = baseType.BaseType.Replace(complexName.First(), "").TrimStart('.');
                nsImports.Add(complexName.First());
            }
            return nsImports;
        }

        /// <summary>
        /// Обработка полей, методов, свойств типа
        /// </summary>
        /// <param name="type"></param>
        public static void ProcessTypeMembers(CodeTypeDeclaration type)
        {
            var newMembersList = new List<CodeTypeMember>();

            /*Обработка для Property*/
            foreach (var member in type.Members.Cast<CodeTypeMember>().Where(tm => !tm.Name.ToLower().Contains("field")))
            {
                if (member is CodeMemberProperty)
                {
                    var castedMember = member as CodeMemberProperty;

                    var newMember = new CodeMemberProperty
                    {
                        Attributes = MemberAttributes.Abstract | MemberAttributes.Public,
                        CustomAttributes = castedMember.CustomAttributes,
                        Name = castedMember.Name,
                        Type = castedMember.Type,
                        HasGet = true,
                        HasSet = true,
                    };

                    newMembersList.Add(newMember);
                    continue;
                }
                /*
                var memberField = member as CodeMemberField;
                if(memberField != null) continue;
                var castedTypeMember = member as CodeTypeMember;
                if (null == castedTypeMember) continue;*/
                
                newMembersList.Add(member);
            }

            type.Members.Clear();
            type.Members.AddRange(newMembersList.ToArray());
        }

        private static void RenameFieldInConstructor(CodeTypeDeclaration type)
        {
            foreach (var ctor in type.Members.OfType<CodeConstructor>())
            {
                foreach (var field in ctor.Statements.OfType<CodeAssignStatement>())
                {
                    var fieldLeft = field?.Left as CodeFieldReferenceExpression;
                    if (fieldLeft == null) continue;

                    foreach (var hasProp in type.Members.OfType<CodeMemberProperty>())
                    {
                        if(!hasProp.Name.ToLower().Equals(fieldLeft.FieldName.ToLower().Replace("field", ""))) continue;
                        fieldLeft.FieldName = hasProp.Name;
                    }
                }
            }
        }

        public static string[] SplitType(string type)
        {
            var lastIndex = type.LastIndexOf('.');
            if (lastIndex == -1) return new [] { "", type };
            var nsName = type.Substring(0, lastIndex);
            return new[] { nsName, type.Replace(nsName, "").TrimStart('.') };
        }

        public static void TryProcessTypes(Dictionary<string, CodeCompileUnit> units,
            Dictionary<string, CodeTypeDeclaration> types)
        {
            var namespaces = new List<string>();

            foreach (var type in types)
            {
                var nsname = TryAddTypeIntoUnit(units, type);

                /*nsname = nsname.Replace("async", "");

                if (!nsname.Contains("service"))
                    nsname = "gistypes";

                if (namespaces.Contains(nsname)) continue;

                namespaces.Add(nsname);*/
            }

        }

        private static string TryAddTypeIntoUnit(Dictionary<string, CodeCompileUnit> units, KeyValuePair<string, CodeTypeDeclaration> type)
        {
            /*пытаемся получить тип сборки*/

            var nsname = GetNamespaceFromAttributes(type);
                nsname = nsname.Replace("async", "");

            if (!nsname.Contains("service"))
                nsname = "gistypes";

            if (!units.ContainsKey(nsname))
            {
                var newUnit = new CodeCompileUnit
                {
                    UserData = { { "ModuleName", nsname } },
                    Namespaces = { new CodeNamespace(), new CodeNamespace(nsname) }
                };

                units.Add(nsname, newUnit);
            }
            
            if(!units[nsname].Namespaces[1].Types.Cast<CodeTypeDeclaration>().Any(t => t.Name.Equals(type.Value.Name)))
            {
                units[nsname].Namespaces[1].Types.Add(type.Value);
            }

            return nsname;
        }

        public static string GetNamespaceFromAttributes(KeyValuePair<string, CodeTypeDeclaration> type)
        {
            var nsname = string.Empty;

            foreach (var attr in type.Value.CustomAttributes.Cast<CodeAttributeDeclaration>())
            {
                foreach (var arg in attr.Arguments.Cast<CodeAttributeArgument>())
                {
                    if (!arg.Name.Equals("Namespace")) continue;

                    var val = arg.Value as CodePrimitiveExpression;
                    if (val != null) nsname = val.Value.ToString();
                }
            }

            if (string.IsNullOrEmpty(nsname))
                return type.Key.Split('.').First().ToLower();

            return nsname.Split("/".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Last().Replace("-", "").Replace("#","");
        }

        public static List<CodeAttributeArgument> GetAttributeArguments(CodeTypeDeclaration type, string attributeName)
        {
            var codeAttributeArguments = new List<CodeAttributeArgument>();

            foreach (var attr in type.CustomAttributes.Cast<CodeAttributeDeclaration>().Where(t => t.Name.Contains(attributeName)))
            {
                codeAttributeArguments.AddRange(attr.Arguments.Cast<CodeAttributeArgument>());
            }

            return codeAttributeArguments;
        }
    }
}
