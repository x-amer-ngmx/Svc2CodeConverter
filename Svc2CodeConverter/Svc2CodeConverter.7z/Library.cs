﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Svc2CodeConverter
{
    public class Library : LibraryExtender
    {
        static readonly string SitLogin = ConfigurationManager.AppSettings["basic_user"] ?? "sit";
        static readonly string SitPassword = ConfigurationManager.AppSettings["basic_password"] ?? "rZ_GG72XS^Vf55ZW";
        static readonly string ServiceEndpoint = ConfigurationManager.AppSettings["servicepoint_sit_01"];
        public static CodeCompileUnit[] LoadSvcData(string[] serviceEndpoints, string assemblyPrefixName)
        {
            var basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.None) { MaxReceivedMessageSize = 52428800 };
            var xmlDictionaryReaderQuotas = new XmlDictionaryReaderQuotas
            {
                MaxNameTableCharCount = 2147483647
            };
            basicHttpBinding.ReaderQuotas = xmlDictionaryReaderQuotas;

            var mexClient =
                new MetadataExchangeClient(basicHttpBinding)
                {
                    MaximumResolvedReferences = 1000,
                    HttpCredentials = new NetworkCredential(SitLogin, SitPassword),
                    ResolveMetadataReferences = true
                };
           
           var concurrentDic = new ConcurrentDictionary<string, CodeCompileUnit>();

            foreach (var serviceEndpoint in serviceEndpoints)
                {
                    Task<MetadataSet> mexClientData = null;
                    var serviceUri =
                        new Uri(serviceEndpoint.Replace("https://api.dom.gosuslugi.ru", ServiceEndpoint) + "?wsdl");
                    do
                    {
                        try
                        {
                            mexClientData = mexClient.GetMetadataAsync(serviceUri, MetadataExchangeClientMode.HttpGet);
                            mexClientData.Wait();
                        }
                        catch (Exception exc)
                        {
                            Console.WriteLine(exc.Message);
                            Console.WriteLine(serviceUri.ToString());
                        }

                        //System.Threading.Thread.Sleep(1000);
                    } while (mexClientData == null);

                    object dataContractImporter;
                    XsdDataContractImporter xsdDcImporter;
                    var options = new ImportOptions();

                    var wsdl = new WsdlImporter(mexClientData.Result);
                    if (!wsdl.State.TryGetValue(typeof(XsdDataContractImporter), out dataContractImporter))
                    {
                        xsdDcImporter = new XsdDataContractImporter { Options = options };
                        wsdl.State.Add(typeof(XsdDataContractImporter), xsdDcImporter);
                    }
                    else
                    {
                        xsdDcImporter = (XsdDataContractImporter)dataContractImporter;
                        if (xsdDcImporter.Options == null)
                        {
                            xsdDcImporter.Options = options;
                        }
                    }

                    IEnumerable<IWsdlImportExtension> exts = wsdl.WsdlImportExtensions;
                    var newExts = new List<IWsdlImportExtension>();

                    newExts.AddRange(wsdl.WsdlImportExtensions);

                    newExts.Add(new WsdlDocumentationImporter());
                    IEnumerable<IPolicyImportExtension> polExts = wsdl.PolicyImportExtensions;

                    wsdl = new WsdlImporter(mexClientData.Result, polExts, newExts);

                    var contracts = wsdl.ImportAllContracts();
                    wsdl.ImportAllEndpoints();
                    wsdl.ImportAllBindings();
                    var generator = new ServiceContractGenerator();

                    foreach (var contract in contracts)
                    {
                        generator.GenerateServiceContractType(contract);
                        generator.TargetCompileUnit.UserData.Add("ModuleName",
                            contract.Name.Replace("PortsType", "Service"));
                        concurrentDic.TryAdd(contract.Name.Replace("PortsType", "Service"),
                            generator.TargetCompileUnit);
                    }
                };

            return concurrentDic.Select(t => t.Value).ToArray();
        }

        public static CodeCompileUnit[] GenerateCodeUnits(CodeCompileUnit[] units)
        {
            /*ТРЕБОВАНИЯ*/
            /*
             * 1) Необходимо создать класс PortsTypeClient и его спутника
             * 2) Проследить за контрактами этого класса
             * 3) Вынести переменные в отдельный модуль
             * 4) Убрать private field - добавить get;set; в автосвойства
             * 5) Расщепить атрибуты
             * 
             */
            
            var allTypes = new Dictionary<string, CodeTypeDeclaration>();
            
            var overallTypesUnit = new CodeCompileUnit
            {
                Namespaces = { new CodeNamespace(""), new CodeNamespace("GisTypes") },
                UserData = { { "ModuleName" , "GisTypes" } }//Не типы сервисов, а общие типы, которые присутствуют в модулях и у них одно и то же имя
            };

            var codeExportUnits = new Dictionary<string, CodeCompileUnit>();
            //var logWriter = new IndentedTextWriter(new StreamWriter(@"c:\\log.txt"));
            
            foreach (var unit in units)
            {
                foreach (var unitNamespace in unit.Namespaces.Cast<CodeNamespace>())
                {
                    foreach (var type in unitNamespace.Types.Cast<CodeTypeDeclaration>())
                    {
                        ProcessType(type);
                        /*if (
                            overallTypesUnit.Namespaces[1].Types.Cast<CodeTypeDeclaration>()
                                .Any(t => t.Name.Equals(type.Name)))
                        {
                            var existsType =
                                overallTypesUnit.Namespaces[1].Types.Cast<CodeTypeDeclaration>().First(t => t.Name.Equals(type.Name));

                            var existsArgs = GetAttributeArguments(existsType, "DataContractAttribute");
                            var typeArgs = GetAttributeArguments(type, "DataContractAttribute");

                            if (!existsArgs.Any() && typeArgs.Any() || existsArgs.Any() && !typeArgs.Any())
                            {

                            }
                            else
                            {
                                if (existsArgs.Select(t => t.Name).Any() && existsArgs.Select(t => t.Name).First() == typeArgs.Select(t => t.Name).First() && existsArgs.Select(t=>t.Value) == typeArgs.Select(t=>t.Value)))
                                {
                                    continue;
                                }
                            }
                        };*/


                        /*var kPrefix = string.Empty;
                        if (allTypes.ContainsKey(unit.UserData["ModuleName"] + "." + type.Name))
                        {
                            kPrefix = "1";
                        }*/

                        //allTypes.Add(unit.UserData["ModuleName"] + "." + type.Name + kPrefix, type);
                        overallTypesUnit.Namespaces[1].Types.Add(type);

                        /*var nsname = GetNamespaceFromAttributes(new KeyValuePair<string, CodeTypeDeclaration>(unit.UserData["ModuleName"] + "." + type.Name, type));
                        type.Name = nsname + '_' + type.Name;
                        overallTypesUnit.Namespaces[1].Types.Add(type);*/
                        //logWriter.WriteLine(nsname + " " + unit.UserData["ModuleName"] + "." + type.Name);

                        /*foreach (var typeMember in type.Members.Cast<CodeTypeMember>())
                        {
                            switch (typeMember.GetType().Name)
                            {
                                case "CodeMemberMethod":
                                    logWriter.WriteLine("   |----" + '(' +typeMember + ')'+ ((CodeMemberMethod)typeMember).ReturnType.BaseType + " " + typeMember.Name);
                                    break;
                                case "CodeMemberField":
                                    logWriter.WriteLine("   |----" + '(' + typeMember + ')' + ((CodeMemberField)typeMember).Type.BaseType + " " + typeMember.Name);
                                    break;
                            }
                        }*/

                    }
                }
            }
            //codeExportUnits.Add("", overallTypesUnit);
            /*Из UNIтов собрали типы, теперь можно попробовать растолкать их по сборкам*/

            //TryProcessTypes(codeExportUnits, allTypes);

            //logWriter.Flush(); logWriter.Close();

            /*Добавляется интерфейс, который должен описывать верхний клиент*/
            /*В интерфейсе описываются типы в виде атрибутов, которые могут быть общими*/
            /*AddEntities(codeExportUnits, allTypes, c => c.Value.IsInterface);*/
            /*Добавляется главный класс - клиент, который отвечает за все методы сервиса*/
            /*AddEntities(codeExportUnits, allTypes, c => c.Value.BaseTypes.Cast<CodeTypeReference>()
                    .Any(t => t.BaseType.Contains("ClientBase")));*/

            /*
             *  AddClientBase(codeExportUnits, allTypes);
                AddInterfaces(codeExportUnits, allTypes);
            */


            //codeExportUnits.Add(overallTypesUnit.UserData["ModuleName"].ToString(), overallTypesUnit);

            /*
            foreach (var unit in units)
            {
                foreach (var unitNamespace in unit.Namespaces.Cast<CodeNamespace>())
                {
                    foreach (var type in unitNamespace.Types.Cast<CodeTypeDeclaration>())
                    {
                        if (!allTypes.ContainsKey(type.Name))
                        {
                            allTypes.Add(type.Name, type);
                        }
                    }
                }
            }
            */

            /*Второй проход - выбирает те типы, которые имеются в двух сборках*/
            //overallTypesUnit.Namespaces[1].Types.Add(type);

            //var currentCompileUnit = units.First();
            //var codeExportUnits = new List<CodeCompileUnit> {overallTypesUnit};

            return codeExportUnits.Select(t => t.Value).ToArray();
        }



        /// <summary>
        /// Создаёт файловое окружение для сервисов
        /// </summary>
        /// <param name="units"></param>
        /// <param name="path"></param>
        public static void CreateServiceSupportWithUnits(CodeCompileUnit[] units, string path)
        {
            var codeDomProvider = CodeDomProvider.CreateProvider("C#");

            foreach (var unit in units)
            {
                var exportFileName = unit.UserData["ModuleName"] + ".cs";
                using (var myTextWriter = new AbstractIndentedTextWriter( new StreamWriter( path.TrimEnd('\\') + '\\' + exportFileName), isVirtual: true) )
                {
                    codeDomProvider.GenerateCodeFromCompileUnit( unit, myTextWriter, GetOptions );
                    myTextWriter.Flush(); myTextWriter.Close();
                }
            }
        }
    }
}

/*
 
var logWriter = new IndentedTextWriter(new StreamWriter(@"c:\\log.txt"));
            logWriter.WriteLine(type.Name);
            logWriter.Flush();logWriter.Close();
                 
*/
